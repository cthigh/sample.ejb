#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.iioptransport-1.0.mf=6a06c5041ea19ab7973cf815bb4bcd9d
lib/com.ibm.ws.transport.iiop.server_1.0.17.jar=5cc26a169a928dd4d8281cc33ab7e458
