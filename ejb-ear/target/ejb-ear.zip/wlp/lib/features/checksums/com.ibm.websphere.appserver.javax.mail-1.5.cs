#Tue May 23 20:10:19 BST 2017
lib/features/com.ibm.websphere.appserver.javax.mail-1.5.mf=c2054da229d7d95dd4e48ed2d64ae264
lib/com.ibm.ws.com.sun.mail.javax.mail.1.5_1.5.17.jar=a01680ed743777bc8468d61e45c1e05a
