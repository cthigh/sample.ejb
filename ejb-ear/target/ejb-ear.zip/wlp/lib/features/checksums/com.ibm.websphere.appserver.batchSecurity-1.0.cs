#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.jbatch.security_1.0.17.jar=6f383190eb5de2c7c5c259a26f92a5d6
lib/features/com.ibm.websphere.appserver.batchSecurity-1.0.mf=6d5b991de42061a854e6772b52c86ee3
