#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.localConnector-1.0.mf=e94720535d0ef37a478d8b25bfe3d0df
lib/com.ibm.ws.jmx.connector.local_1.0.17.jar=c805d803c2aaa8a8d4ebb3f2e7799480
