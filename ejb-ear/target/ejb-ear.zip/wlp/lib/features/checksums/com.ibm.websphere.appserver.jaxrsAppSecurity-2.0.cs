#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.jaxrs.2.0.security_1.0.17.jar=3fd62c5e7f992350f90c591de9f44915
lib/features/com.ibm.websphere.appserver.jaxrsAppSecurity-2.0.mf=61652d0b414b89c8808452fc4f20d60c
