#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.transaction.management_1.0.17.jar=a31e3c486d31411b70ad83e09fb10df0
lib/features/com.ibm.websphere.appserver.j2eeManagement1.1-transaction1.2.mf=e250ebb8cda22810e41674f74f61314e
