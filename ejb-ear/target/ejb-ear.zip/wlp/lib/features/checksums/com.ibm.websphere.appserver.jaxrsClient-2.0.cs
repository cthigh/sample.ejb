#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.jaxrs.2.0.client_1.0.17.jar=41d40d4e7c3d2dd4e91e69f4cd2fe647
lib/features/com.ibm.websphere.appserver.jaxrsClient-2.0.mf=b79e35145128d2e6f2e94fe03ad778cd
