#Tue May 23 20:10:20 BST 2017
dev/api/spec/com.ibm.websphere.javaee.jms.2.0_1.0.17.jar=99bb6e85de904d53763c1e659e8fafed
lib/com.ibm.ws.messaging.jmsspec.common_1.0.17.jar=9e8bb1d19247e1b701f6703988c89a27
lib/features/com.ibm.websphere.appserver.internal.jms-2.0.mf=44d8fb6a0d0b8c249a60224938356cdd
