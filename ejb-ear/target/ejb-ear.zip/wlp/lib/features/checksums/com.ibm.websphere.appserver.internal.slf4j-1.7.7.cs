#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.internal.slf4j-1.7.7.mf=b4517bb5143cb08944630c638bbe5552
lib/com.ibm.ws.org.slf4j.api.1.7.7_1.0.17.jar=a40a6bd092242d00c06d4122a1ce058f
lib/com.ibm.ws.org.slf4j.jdk14.1.7.7_1.0.17.jar=8bdcdc23634d57ebc06824a2d78d4a3f
