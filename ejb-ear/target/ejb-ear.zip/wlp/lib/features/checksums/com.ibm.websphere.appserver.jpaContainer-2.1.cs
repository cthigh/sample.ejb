#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.jpaContainer-2.1.mf=967f03e6a0c00ab1629bebbdce3c7457
lib/com.ibm.ws.jpa.container.thirdparty_1.0.17.jar=30547a309d928cf14be276560e3a2597
lib/com.ibm.ws.jpa.container_1.0.17.jar=d905306bb16f0031d0cf96b58de2148c
lib/com.ibm.ws.jpa.container.v21_1.0.17.jar=864b2d065448fc431248fee9991d4d53
