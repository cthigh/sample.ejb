#Tue May 23 20:10:19 BST 2017
lib/features/com.ibm.websphere.appserver.restHandler-1.0.mf=c7b5b1e89177fb034520cd33a0ca671a
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restHandler_2.0-javadoc.zip=50f2e51994d56bd940cb13a5ad7e2b19
lib/com.ibm.ws.rest.handler_1.0.17.jar=fdfaea6ee7c91781b26d5918632eb8c1
dev/spi/ibm/com.ibm.websphere.appserver.spi.restHandler_2.0.17.jar=a921854bd921ae154f2bd90c62f2ed1f
lib/com.ibm.websphere.jsonsupport_1.0.17.jar=702e8dac4cc20a3954903842de00710b
lib/com.ibm.websphere.rest.handler_1.0.17.jar=57ed1df8390c4fc7d4a332688a317d4d
lib/com.ibm.ws.org.joda.time.1.6.2_1.0.17.jar=75ea43a27f300be3970c7ba32eb42591
