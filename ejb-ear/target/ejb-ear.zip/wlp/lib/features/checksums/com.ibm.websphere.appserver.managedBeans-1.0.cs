#Tue May 23 20:10:20 BST 2017
dev/api/ibm/schema/ibm-managed-bean-bnd_1_0.xsd=914d243e72b5fdf8dfbff4f6be3e4bc9
dev/api/ibm/schema/ibm-managed-bean-bnd_1_1.xsd=d90f6abac37958438d8018aa10797eee
lib/features/com.ibm.websphere.appserver.managedBeans-1.0.mf=4fd8a4df773bc88e7c2c8544f9ebc18c
lib/com.ibm.ws.managedbeans_1.0.17.jar=9aee26e65dfa54737c3fe958478996ee
