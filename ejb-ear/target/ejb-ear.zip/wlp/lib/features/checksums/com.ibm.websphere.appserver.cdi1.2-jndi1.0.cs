#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.cdi1.2-jndi1.0.mf=d2b0ccb34de76a3d577cdbe34e91204a
lib/com.ibm.ws.cdi.1.2.jndi_1.0.17.jar=dee5514f19a88a177e87dfc3ca5a95a2
