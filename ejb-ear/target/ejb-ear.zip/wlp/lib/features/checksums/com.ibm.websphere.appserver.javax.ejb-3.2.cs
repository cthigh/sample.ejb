#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.javax.ejb-3.2.mf=cbb7f0900e1d47420cd63c603584301a
dev/api/spec/com.ibm.websphere.javaee.ejb.3.2_1.0.17.jar=b50cfa599ebfcaa7e1e57fdc6e3eefbb
