#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.jaxrs.2.0.beanvalidation_1.0.17.jar=9d796ea73757a56fe0f262d3a50fdcc0
lib/features/com.ibm.websphere.appserver.jaxrsBeanValidation-2.0.mf=2fda0acdbe0496ae38704f56e312735c
