#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.javaMail-1.5.mf=b2e0570d28b403828bb1517075438550
lib/com.ibm.ws.javamail_1.5.17.jar=5f757138190ab76d5d439f871750474a
dev/api/spec/com.ibm.websphere.javaee.mail.1.5_1.0.17.jar=f8b964c906c62893545571163a0f1e0b
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.mail_1.0.17.jar=14c0798d0c76a6bfe3b64a1b50612a0d
