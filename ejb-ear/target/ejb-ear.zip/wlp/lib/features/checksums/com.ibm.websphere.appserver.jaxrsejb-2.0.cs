#Tue May 23 20:10:19 BST 2017
lib/features/com.ibm.websphere.appserver.jaxrsejb-2.0.mf=6f3b7b6a26731c72079bb70151cafe67
lib/com.ibm.ws.jaxrs.2.0.ejb_1.0.17.jar=5ca67c0a399f52529db1a11882b506df
