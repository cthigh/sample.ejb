#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.org.glassfish.json.1.0_1.0.17.jar=157fc0b297fede66151e51f9ded02649
lib/features/com.ibm.websphere.appserver.jsonp-1.0.mf=a1abbe7730128303646ec819405e5dab
dev/api/spec/com.ibm.websphere.javaee.jsonp.1.0_1.0.17.jar=f93feb671ba656f5dd7781f42241ffac
