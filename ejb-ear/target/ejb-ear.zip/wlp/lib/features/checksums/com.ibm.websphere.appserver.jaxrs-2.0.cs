#Tue May 23 20:10:19 BST 2017
lib/features/com.ibm.websphere.appserver.jaxrs-2.0.mf=1eaf16cb67e27de9faef9722656658fd
