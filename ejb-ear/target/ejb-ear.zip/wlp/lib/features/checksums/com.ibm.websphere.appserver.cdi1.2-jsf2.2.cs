#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.cdi1.2-jsf2.2.mf=af37d85541ee6f96b99e60621ab0cd85
lib/com.ibm.ws.cdi.1.2.jsf_1.0.17.jar=20f0017607a74c45b5a8ee0aed0f359a
