#Tue May 23 20:10:20 BST 2017
dev/api/spec/com.ibm.websphere.javaee.transaction.1.2_1.0.17.jar=1552f6a00ef40300720bb4cc464a1e4e
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.17.jar=1993bc7194ff5cbdc44ceb5d885ef8ec
lib/features/com.ibm.websphere.appserver.jta-1.2.mf=9af34fb0da9013af77d706f22f3c3512
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=1aa77d4855381dcf7f44eed27dc37dba
