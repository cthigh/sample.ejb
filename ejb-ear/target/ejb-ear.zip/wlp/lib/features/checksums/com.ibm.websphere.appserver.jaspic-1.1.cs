#Tue May 23 20:10:20 BST 2017
dev/spi/ibm/com.ibm.websphere.appserver.spi.jaspic_1.1.17.jar=021e9e70a8de18b4701e03ede192a6a1
dev/api/spec/com.ibm.websphere.javaee.jaspic.1.1_1.0.17.jar=e4d498e7165620268510c7db315c4924
lib/com.ibm.ws.security.jaspic.1.1_1.0.17.jar=ca596563c705c18b02052448ba93057a
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.jaspic_1.1-javadoc.zip=a54fe4033520b3b93a31b45090ffcd16
lib/features/com.ibm.websphere.appserver.jaspic-1.1.mf=36fb2ef77e945c4111535c565e87cc3b
