#Tue May 23 20:10:20 BST 2017
dev/api/spec/com.ibm.websphere.javaee.cdi.1.2_1.2.17.jar=85996b35ba77e7aadef938b36477cc54
lib/features/com.ibm.websphere.appserver.javax.cdi-1.2.mf=bdc7a4c762d35a22c14c2100e9dd852a
