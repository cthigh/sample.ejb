#Tue May 23 20:10:19 BST 2017
bin/tools/ws-client.jar=39988491194b46d95ca2afb4e9d5663d
lib/com.ibm.ws.appclient.boot_1.0.17.jar=5463a0b18b7446e6354fd0ac0c38f0f5
lib/features/com.ibm.websphere.appclient.client-1.0.mf=7f558202f7e40a7a5045e30a953f13f8
