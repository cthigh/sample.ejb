#Tue May 23 20:10:19 BST 2017
lib/com.ibm.ws.session.monitor_1.0.17.jar=0381013c8536b97f5f940a76f9056d16
dev/api/ibm/com.ibm.websphere.appserver.api.sessionstats_1.0.17.jar=6db57595f0a4c92be4c84ea11b158071
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.sessionstats_1.0-javadoc.zip=1cbfb6f6a308262c9bb63a4869b672f4
lib/features/com.ibm.websphere.appserver.sessionMonitor-1.0.mf=814d3329a3d8ed2fad5ef555d0b00776
