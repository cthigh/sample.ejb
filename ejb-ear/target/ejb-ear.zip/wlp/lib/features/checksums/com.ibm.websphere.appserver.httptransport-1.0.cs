#Tue May 23 20:10:20 BST 2017
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.httptransport_1.1-javadoc.zip=acc1c2a1201768947a92c2f974783cd9
lib/features/com.ibm.websphere.appserver.httptransport-1.0.mf=6babbdfa1d74eb7180686ba38082cb42
dev/spi/ibm/com.ibm.websphere.appserver.spi.httptransport_1.1.17.jar=354af683474d8d1576bce777afbc0f44
lib/com.ibm.ws.transport.http_1.0.17.jar=1ce1a0eb6487a1c485fc95d7a999adea
