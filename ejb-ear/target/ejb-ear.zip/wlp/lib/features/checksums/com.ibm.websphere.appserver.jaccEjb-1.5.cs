#Tue May 23 20:10:19 BST 2017
dev/api/spec/com.ibm.websphere.javaee.jacc.1.5_1.0.17.jar=a611321d4e7e7ea421dbec11374f1fa7
lib/com.ibm.ws.security.authorization.jacc.ejb_1.0.17.jar=77bae2c1c8759320230043c81f03b97b
lib/features/com.ibm.websphere.appserver.jaccEjb-1.5.mf=fa99bca08fb45cdd5aa3be5a53fa92e2
