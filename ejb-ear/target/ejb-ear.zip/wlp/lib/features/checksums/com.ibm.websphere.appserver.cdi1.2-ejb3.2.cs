#Tue May 23 20:10:19 BST 2017
lib/com.ibm.ws.cdi.1.2.ejb_1.0.17.jar=945cd2ef7ea4b7d23217422dbd1b9a3e
lib/features/com.ibm.websphere.appserver.cdi1.2-ejb3.2.mf=0f69acb3abeeed5b380562e6c82a9377
