#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.j2eeManagementClient-1.1.mf=c5c1938a69e93d2529485ecb2e6c7688
dev/api/spec/com.ibm.websphere.javaee.management.j2ee.1.1_1.0.17.jar=6f7351bb743bdca4cb8afe0a07544d74
