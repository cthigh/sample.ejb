#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.jpaContainer2.1-cdi1.2.mf=474a1f584bf4183008175e317fdbbe7a
lib/com.ibm.ws.jpa.container.v21.cdi_1.0.17.jar=74359b3b6bc1f0a0ecf792266a2df869
