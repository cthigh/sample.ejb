#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.jpa2.0-2.1-bv1.1.mf=02ba439c12d80bec215cf4b2d49388ee
lib/com.ibm.ws.jpa.container.beanvalidation.1.1_1.0.17.jar=0dfec3a9f4378720ed6d3c67b85ddab9
