#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.jeeMetadataContext-1.0.mf=9540749d572b53f33f763f39f8163377
lib/com.ibm.ws.javaee.metadata.context_1.0.17.jar=55d494066b4e99a9c687d88d78b113c2
