#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.ejbliteJPA-1.0.mf=7aac195564761ecda40567f14139fbc7
lib/com.ibm.ws.ejbcontainer.jpa_1.0.17.jar=1f686d27524e373e5b85cd9b5e9be884
