#Tue May 23 20:10:19 BST 2017
lib/features/com.ibm.websphere.appserver.internal.jaxrs-2.0.mf=98d8006d35c70a2fffb3e3b615fa5dd2
lib/com.ibm.ws.jaxrs.2.0.client_1.0.17.jar=41d40d4e7c3d2dd4e91e69f4cd2fe647
dev/api/spec/com.ibm.websphere.javaee.jaxrs.2.0_1.0.17.jar=f4220929fc34166148c3865be1297dce
lib/com.ibm.ws.jaxrs.2.0.server_1.0.17.jar=4e7fa174834a00abf89483fda102a711
lib/com.ibm.ws.jaxrs.2.0.web_1.0.17.jar=f85c8bd66786e2550299bd28cb704844
lib/com.ibm.ws.org.apache.xml.resolver.1.2_1.0.17.jar=9b873ceeb2cb026ab25537ed4756a273
lib/com.ibm.ws.org.apache.ws.xmlschema.core.2.0.3_1.0.17.jar=272e081d456b69c792208d3db181a594
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs20_1.0.17.jar=d5752f68aacb43439544bf8aba7bc02a
lib/com.ibm.ws.org.apache.neethi.3.0.2_1.0.17.jar=e91719c9a4e19498acce492eb26d964a
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jaxrs20_1.0-javadoc.zip=cc1193c6c991a607c5aac0a8772df378
lib/com.ibm.ws.jaxrs.2.0.common_1.0.17.jar=885cf769d264e3d9a52457d4a26925d3
bin/jaxrs/tools/wadl2java.jar=9cde7f1d435b8158a25c9d1b4ad3ea09
lib/com.ibm.ws.jaxrs.2.0.tools_1.0.17.jar=44562dbf54c3c003f815d7ed75eabfc5
