#Tue May 23 20:10:20 BST 2017
dev/api/spec/com.ibm.websphere.javaee.validation.1.1_1.0.17.jar=451cb73b81987f240283e8ddf995eaad
lib/features/com.ibm.websphere.appserver.javax.validation-1.1.mf=694f8e5942034aaa6344d35c276a09aa
