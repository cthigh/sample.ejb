#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.javamail.management.j2ee_1.0.17.jar=1dae313877ce6a59c6306e1d0a8287f8
lib/features/com.ibm.websphere.appserver.javaMailJ2eeManagement-1.0.mf=a4cdd129907e6c269de84607237cf38f
