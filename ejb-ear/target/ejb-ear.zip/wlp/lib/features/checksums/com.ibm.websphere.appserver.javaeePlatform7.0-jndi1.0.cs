#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.javaeePlatform7.0-jndi1.0.mf=1587eda4c55c30773815b304ddc8d88f
lib/com.ibm.ws.javaee.platform.v7.jndi_1.0.17.jar=e8631e03b710860e6e9cf5622770fb8d
