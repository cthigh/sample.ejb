#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.javax.interceptor-1.2.mf=9b6a5dc3cbf1800887923446b239b904
dev/api/spec/com.ibm.websphere.javaee.interceptor.1.2_1.0.17.jar=8cc0355f3ab8145a26ea269b2c43094e
