#Tue May 23 20:10:19 BST 2017
lib/features/com.ibm.websphere.appserver.ejbLiteCore-1.0.mf=cbaab8499edbf42bacadd5b6cce366fb
lib/com.ibm.ws.ejbcontainer.session_1.0.17.jar=4f44033fc27733e3d525a0c62eee51b0
