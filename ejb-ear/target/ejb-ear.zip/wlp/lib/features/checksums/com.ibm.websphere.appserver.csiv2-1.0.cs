#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.csiv2-1.0.mf=6e8494ecc097d959ca8f50e40ed459cf
lib/com.ibm.ws.security.csiv2_1.0.17.jar=1b36e4ddb6f22af5688fbbd4f6903ff0
lib/com.ibm.ws.security.csiv2.common_1.0.17.jar=18d942f4a4171fc56aa55cb6440f30ae
