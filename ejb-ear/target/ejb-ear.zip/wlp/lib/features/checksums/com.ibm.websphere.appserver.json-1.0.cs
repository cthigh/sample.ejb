#Tue May 23 20:10:19 BST 2017
dev/api/ibm/com.ibm.websphere.appserver.api.json_1.0.17.jar=9f888141c43fb0dc0a76c8469f64b2dd
lib/features/com.ibm.websphere.appserver.json-1.0.mf=8bb40818031b44823dbc8f4a794873c1
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.json_1.0-javadoc.zip=58cb87efbbb282c9367053f9672c1821
lib/com.ibm.json4j_1.0.17.jar=9d35916e57f329fb945a55639e3f08c9
