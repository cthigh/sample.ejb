#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.cdi1.2-appSecurityClient1.0.mf=709c97ee8f15475259dea78fd0573f28
lib/com.ibm.ws.cdi.1.2.client_1.0.17.jar=2e0853606b978c7873e780ad799f4f55
