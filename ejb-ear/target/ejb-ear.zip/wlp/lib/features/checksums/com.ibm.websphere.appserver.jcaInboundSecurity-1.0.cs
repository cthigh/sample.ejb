#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.jca.inbound.security_1.0.17.jar=e953040bf829eca0a667bd1aed030d17
dev/api/spec/com.ibm.websphere.javaee.jaspic.1.1_1.0.17.jar=e4d498e7165620268510c7db315c4924
lib/features/com.ibm.websphere.appserver.jcaInboundSecurity-1.0.mf=230326e0c02fabe045b8842cb0d8f3b7
