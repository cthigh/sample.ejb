#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.javaee.persistence.api.2.1_1.0.17.jar=46f9a95ee7072afa242496f7f2066aad
lib/features/com.ibm.websphere.appserver.javax.persistence-2.1.mf=edd433b41fad1350b76d61df1041e632
dev/api/spec/com.ibm.websphere.javaee.persistence.2.1_1.0.17.jar=d0d6ab9e6c24ac129bc0986111003dd7
