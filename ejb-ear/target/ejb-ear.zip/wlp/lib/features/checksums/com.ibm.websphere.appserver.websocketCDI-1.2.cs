#Tue May 23 20:10:19 BST 2017
lib/features/com.ibm.websphere.appserver.websocketCDI-1.2.mf=7d233430af7f15ffa9dba9758bbc4905
lib/com.ibm.ws.wsoc.cdi.weld_1.0.17.jar=6f2a847269f2d26c16ad9b5c494a0961
