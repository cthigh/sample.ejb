#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.cdi1.2-transaction1.2.mf=6d957c6a8d6e2f0bb6a526a7142defbc
lib/com.ibm.ws.cdi.1.2.transaction_1.0.17.jar=2cb1251359b24097840fe1dce7b59bf6
