#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.jaxws.cdi_1.0.17.jar=54ccfaccffc816404a16e71f603cf84d
lib/features/com.ibm.websphere.appserver.jaxwscdi-2.2.mf=d3bd6508f071a8223d7ff1316e92d087
