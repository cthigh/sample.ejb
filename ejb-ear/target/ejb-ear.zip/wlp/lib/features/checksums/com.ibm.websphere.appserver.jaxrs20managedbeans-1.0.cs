#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.jaxrs.2.0.managedbeans_1.0.17.jar=2da3c4d64117f7674c9a7f7824f76cdd
lib/features/com.ibm.websphere.appserver.jaxrs20managedbeans-1.0.mf=072d25e675dfd987cb01301e50190ecc
