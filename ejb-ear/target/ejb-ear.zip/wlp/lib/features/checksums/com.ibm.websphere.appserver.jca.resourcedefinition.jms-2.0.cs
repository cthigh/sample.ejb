#Tue May 23 20:10:19 BST 2017
lib/features/com.ibm.websphere.appserver.jca.resourcedefinition.jms-2.0.mf=2aa6c927d69352c0662d4acbcf6a7920
lib/com.ibm.ws.jca.resourcedefinition.jms.2.0_1.0.17.jar=93aa9b80fad1bf198b8529a711de6b05
