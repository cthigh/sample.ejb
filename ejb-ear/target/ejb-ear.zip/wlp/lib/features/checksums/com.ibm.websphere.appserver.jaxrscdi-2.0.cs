#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.jaxrscdi-2.0.mf=0ec215bfbf31d5c8a9d84356e2c2c2ea
lib/com.ibm.ws.jaxrs.2.0.cdi_1.0.17.jar=de8e007fbb89ac7f04702fa0704db600
