#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.transaction-1.1.mf=65f1badc9d4bec231987ce9bd15046b9
lib/com.ibm.ws.recoverylog_1.0.17.jar=8dd4a0bb131ba937c61c2ab88d7c19a7
lib/com.ibm.rls.jdbc_1.0.17.jar=a4a41f0c7818e2897573514bfee66885
dev/spi/ibm/com.ibm.websphere.appserver.spi.transaction_1.1.17.jar=510ed841a8e435142e2a1599e0eb2234
lib/com.ibm.ws.transaction_1.0.17.jar=6f721905e6d00082497dd99f06b8a067
lib/com.ibm.tx.jta_1.0.17.jar=0406c72d1913f1a3d9db0ca750aefd40
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.transaction_1.1-javadoc.zip=604fc5202b447386b00ee7f00ef8706e
lib/com.ibm.ws.tx.embeddable_1.0.17.jar=8ae127fcb833a4a9e70aa13e8bd4f355
lib/com.ibm.tx.ltc_1.0.17.jar=df30d0fe26756d19af8e6d91c5d8bc12
lib/com.ibm.tx.util_1.0.17.jar=15dfa16e7139a18550c8ced92fe67be1
lib/com.ibm.ws.tx.jta.extensions_1.0.17.jar=3b42a57d3fdbe6586bc9bddb824b4ba1
