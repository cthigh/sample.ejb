#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.beanvalidation.v11.cdi_1.0.17.jar=7b43f1ac144c219401bcb89b922588e6
lib/features/com.ibm.websphere.appserver.beanValidationCDI-1.0.mf=9ae280a76fb4e005e198b1a19c07438b
