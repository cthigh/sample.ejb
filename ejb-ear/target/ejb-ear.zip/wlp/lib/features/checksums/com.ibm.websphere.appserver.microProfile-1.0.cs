#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.require.java8_1.0.17.jar=8cf1a23380158aad7b5df16d24a430af
lib/features/com.ibm.websphere.appserver.microProfile-1.0.mf=5d61ded6414b26bdaf977331bbbe8884
