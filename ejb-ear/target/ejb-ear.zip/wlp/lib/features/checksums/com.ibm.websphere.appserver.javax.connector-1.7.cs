#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.javax.connector-1.7.mf=53d3fb3124240c47e050eec760515dde
dev/api/spec/com.ibm.websphere.javaee.connector.1.7_1.0.17.jar=5963a2ec9b733e66454a116d8d60cea8
