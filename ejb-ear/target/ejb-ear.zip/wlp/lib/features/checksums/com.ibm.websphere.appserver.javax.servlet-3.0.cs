#Tue May 23 20:10:20 BST 2017
dev/api/spec/com.ibm.websphere.javaee.servlet.3.0_1.0.17.jar=4cccb2663b1bc7e62584af8f04e94d52
lib/features/com.ibm.websphere.appserver.javax.servlet-3.0.mf=68db90d9c5a7b5bbd2639486808029bd
