#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.jndi1.0-iiop1.0.mf=6522cb186c426deb066ef34dee0de663
lib/com.ibm.ws.jndi.iiop_1.0.17.jar=f4b4358f20d19552acee4d7e1a27938a
