#Tue May 23 20:10:20 BST 2017
dev/api/spec/com.ibm.websphere.javaee.websocket.1.1_1.0.17.jar=41d0c0b289623032cf5dcebe0c52f376
dev/api/ibm/com.ibm.websphere.appserver.api.wsoc_1.0.17.jar=2f9749fc1ea7bfb8a9ad53c71a000afb
lib/com.ibm.ws.wsoc.1.1_1.0.17.jar=327a0fa258ea1e33c25b2fac73623160
lib/com.ibm.ws.wsoc_1.0.17.jar=bfb4d9d94a841d385bb03c45f5f1b1c1
lib/features/com.ibm.websphere.appserver.websocket-1.1.mf=e4b8e973cedff8282c8b9c568c3f732c
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.wsoc_1.0-javadoc.zip=02117218656445ff5dec03239154527b
