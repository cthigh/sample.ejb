#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.javax.annotation-1.1.mf=b70fa337d53d18c5207714e7d977aec2
dev/api/spec/com.ibm.websphere.javaee.annotation.1.1_1.0.17.jar=a613b9faa24dc6574821c7f2aa050b66
