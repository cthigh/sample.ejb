#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.webcontainer.monitor_1.0.17.jar=355025099fdd1223cc21024dfaa64e25
lib/features/com.ibm.websphere.appserver.webcontainerMonitor-1.0.mf=d78d6800f354160e5df6cda1470a4baf
