#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.cdi.1.2.security_1.0.17.jar=5c446ae4db3ca0a646b11eb0fd37e7ce
lib/features/com.ibm.websphere.appserver.cdi1.2-appSecurity1.0.mf=1f3fc92e6497a192c079c91c3d179b35
