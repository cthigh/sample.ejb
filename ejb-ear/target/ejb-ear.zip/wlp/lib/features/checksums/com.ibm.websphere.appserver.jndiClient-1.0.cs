#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.jndi.remote.client_1.0.17.jar=5f8ce32328cf7a3f90f402f75fe8ac30
lib/features/com.ibm.websphere.appserver.jndiClient-1.0.mf=6f5e580cb2a84e33208b348244d67bb4
