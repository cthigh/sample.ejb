#Tue May 23 20:10:20 BST 2017
dev/api/spec/com.ibm.websphere.javaee.connector.1.6_1.0.17.jar=996f141a92ad1ceb1cfba4adf401fd99
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.6.mf=439db1611700929e5a72449c441df0b7
