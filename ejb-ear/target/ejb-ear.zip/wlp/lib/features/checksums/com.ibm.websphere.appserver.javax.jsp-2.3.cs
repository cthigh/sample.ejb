#Tue May 23 20:10:20 BST 2017
dev/api/spec/com.ibm.websphere.javaee.jsp.2.3_1.0.17.jar=3a183a0025b81301e041ee25c9dbc905
lib/features/com.ibm.websphere.appserver.javax.jsp-2.3.mf=ef71a67ac08621c93c94a2a9478665d8
