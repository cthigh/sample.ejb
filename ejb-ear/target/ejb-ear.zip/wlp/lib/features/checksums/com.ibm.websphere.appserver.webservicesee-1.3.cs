#Tue May 23 20:10:20 BST 2017
dev/api/spec/com.ibm.websphere.javaee.jaxws.2.2_1.0.17.jar=19bcc121a2a964f96f4eb0e2dd47f60d
lib/com.ibm.ws.javaee.ddmodel.ws_1.0.17.jar=977568ee599fcdd2c9ea201b11bbdebb
lib/features/com.ibm.websphere.appserver.webservicesee-1.3.mf=791e695d5d2061443744cc9b7a317ac0
lib/com.ibm.ws.webservices.javaee.common_1.0.17.jar=68bbe1780e6b8140732ed402550756a6
