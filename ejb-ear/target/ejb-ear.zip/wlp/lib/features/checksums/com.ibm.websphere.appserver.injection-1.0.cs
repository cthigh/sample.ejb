#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.injection_1.0.17.jar=df2e232aa6196a47b12a0a3319b8ecf1
lib/features/com.ibm.websphere.appserver.injection-1.0.mf=1cccb5cf3e1e93d0f622425cb6b052ae
