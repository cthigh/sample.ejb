#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.jdbc.management.j2ee_1.0.17.jar=68afa82ccc5b73ba2519f108087f2786
lib/features/com.ibm.websphere.appserver.jdbcJ2eeManagement-1.0.mf=93ce27fbb6cc2466279f462b67fefd30
