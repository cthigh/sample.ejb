#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.connectionManagement-1.0.mf=e36cf27e6827300dced6145d3fa15c8a
lib/com.ibm.ws.jca.cm_1.0.17.jar=7473ceb52f8d72bc305e6a3f7692f4ad
