#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.cdi-1.2-batch-1.0.mf=917689e78b90d5f323fb35ddf048754f
lib/com.ibm.ws.jbatch.cdi_1.0.17.jar=1e6ca0396445fe2e3405f32ed695e796
