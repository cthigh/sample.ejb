#Tue May 23 20:10:20 BST 2017
dev/api/spec/com.ibm.websphere.javaee.annotation.1.2_1.0.17.jar=34ce1def40c57fe3c0e092537e7ab345
lib/features/com.ibm.websphere.appserver.javax.annotation-1.2.mf=054d3e064377e0042c9d4d5709b11966
