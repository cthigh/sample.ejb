#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.jca.management.j2ee_1.0.17.jar=b7b0f5a4321010dfdd68f0f280914ddf
lib/features/com.ibm.websphere.appserver.jcaJ2eeManagement-1.0.mf=c4242af4901baff740f58b9ed376ccfc
