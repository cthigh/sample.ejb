#Tue May 23 20:10:19 BST 2017
lib/com.ibm.ws.jca_1.0.17.jar=ad8e7a174b0e10d65bce71dde0464435
lib/features/com.ibm.websphere.appserver.internal.jca-1.6.mf=aae20bfb36aaadd5a388e3d726761bd6
lib/com.ibm.ws.jca.utils_1.0.17.jar=0cb69b11efe5d3dbbbf5bcf9c290948b
lib/com.ibm.ws.jca.feature_1.0.17.jar=ff2bd12791ae37677660dd930d55ded2
