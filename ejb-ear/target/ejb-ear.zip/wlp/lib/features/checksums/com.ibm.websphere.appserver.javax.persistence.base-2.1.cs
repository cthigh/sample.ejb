#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.javaee.persistence.2.1_1.0.17.jar=1c93506abe132686c7dd78639e1f1a34
lib/features/com.ibm.websphere.appserver.javax.persistence.base-2.1.mf=904d9f27969ef31d1bf747806756e57f
