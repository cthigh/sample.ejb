#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.jndiJ2eeManagement-1.0.mf=8f77f7c8955b5ceeaac43b576effa158
lib/com.ibm.ws.jndi.management.j2ee_1.0.17.jar=259fd4a533de0e394762b4391eefe173
