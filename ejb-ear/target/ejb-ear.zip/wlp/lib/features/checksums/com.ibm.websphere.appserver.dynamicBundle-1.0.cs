#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.dynamicBundle-1.0.mf=47d3dc6ea7a99dd0096298a3465ce23c
lib/com.ibm.ws.dynamic.bundle_1.0.17.jar=7a8ce800e139d9a5f74fcf6e02fd59dc
