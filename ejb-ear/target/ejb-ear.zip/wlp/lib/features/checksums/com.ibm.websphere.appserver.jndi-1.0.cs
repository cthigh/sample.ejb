#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.org.apache.aries.jndi.api_1.1.17.jar=49faa9c392a40d9dfe09570c74b084a0
lib/com.ibm.ws.jndi.url.contexts_1.0.17.jar=86ca4541f856cc0291609c77e865799c
lib/features/com.ibm.websphere.appserver.jndi-1.0.mf=e035562346cc19d16543b9ff9d408265
lib/com.ibm.ws.jndi_1.0.17.jar=5670d42d1807cea605334f6aded1865e
lib/com.ibm.ws.org.apache.aries.jndi.core_1.1.17.jar=b4e99ba1e9eb77d7db00ddc5ac84026a
