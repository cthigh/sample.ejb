#Tue May 23 20:10:19 BST 2017
dev/api/spec/com.ibm.websphere.javaee.interceptor.1.1_1.0.17.jar=bc56dc46bc8721fa0c3163a4b5307a5f
lib/features/com.ibm.websphere.appserver.javax.interceptor-1.1.mf=55b1eb84cf5a1455f6de96abeb031aaa
