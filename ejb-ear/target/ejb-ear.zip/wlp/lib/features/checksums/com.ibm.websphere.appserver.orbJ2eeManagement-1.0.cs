#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.orbJ2eeManagement-1.0.mf=5f5fa49956e2d9b4642b638da039c8bd
lib/com.ibm.ws.transport.iiop.management.j2ee_1.0.17.jar=b017d126daa8d95b9b32caa339a96918
