#Tue May 23 20:10:19 BST 2017
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.17.jar=1993bc7194ff5cbdc44ceb5d885ef8ec
lib/features/com.ibm.websphere.appserver.jta-1.1.mf=c2d9a592192bd8e5198e927700c4fd9b
dev/api/spec/com.ibm.websphere.javaee.transaction.1.1_1.0.17.jar=611bf4c6cd151f45eaf0fe5a7093e551
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=1aa77d4855381dcf7f44eed27dc37dba
