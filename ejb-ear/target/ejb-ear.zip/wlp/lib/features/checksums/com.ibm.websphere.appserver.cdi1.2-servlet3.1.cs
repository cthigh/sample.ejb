#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.cdi1.2-servlet3.1.mf=e0b9f2c735f99cba80d999f98f1f3d99
dev/api/spec/com.ibm.websphere.javaee.jsp.2.3_1.0.17.jar=3a183a0025b81301e041ee25c9dbc905
lib/com.ibm.ws.cdi.1.2.web_1.0.17.jar=e3e32244e1cb557844f9ddfcd1a8aceb
