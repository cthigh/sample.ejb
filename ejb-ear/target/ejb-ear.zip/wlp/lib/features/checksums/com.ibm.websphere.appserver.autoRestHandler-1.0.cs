#Tue May 23 20:10:20 BST 2017
dev/spi/ibm/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0.17.jar=86f4abae8dbc5b92668e37046b8e918a
lib/com.ibm.websphere.collective.plugins_1.0.17.jar=88fafbb73a900506aea992078031eccf
lib/features/com.ibm.websphere.appserver.autoRestHandler-1.0.mf=6ffe9fe338373d729647470d77d4cb1f
lib/com.ibm.websphere.rest.api.discovery_1.0.17.jar=2667165aeb63f557db9e98fb1675c6cc
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.collectivePlugins_2.0-javadoc.zip=cdec477f4ed4ec83132a35a0d6022a90
dev/spi/ibm/com.ibm.websphere.appserver.spi.collectivePlugins_2.0.17.jar=04be94d172583d145a8d60827d8b87b8
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0-javadoc.zip=66e31841033641f5cb39cb6ab4aed58e
