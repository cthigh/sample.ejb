#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.connectionpoolmonitor-1.0.mf=4b291830645ddd9de96fefff2e08fa14
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.connectionpool_1.0-javadoc.zip=a53b422b771ea0090a52d2db276d09d4
dev/api/ibm/com.ibm.websphere.appserver.api.connectionpool_1.0.17.jar=c022b8d7ddef6731b187939e824baf91
lib/com.ibm.ws.connectionpool.monitor_1.0.17.jar=e15d958279293da27efa52d1a6bb8f0a
