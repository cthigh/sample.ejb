#Tue May 23 20:10:20 BST 2017
lib/com.ibm.ws.messaging.jms.defaultresource_1.0.17.jar=47a17766d68fb82951637265120f75a4
lib/features/com.ibm.websphere.appserver.jms.defaultresource-1.0.mf=35a377d5acae25163bae2e3ff91316c0
