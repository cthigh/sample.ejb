#Tue May 23 20:10:20 BST 2017
lib/features/com.ibm.websphere.appserver.cdi1.2-jms-2.0.mf=56fae88e608faffff8b388d3ac411d28
lib/com.ibm.ws.cdi.1.2.jms_1.0.17.jar=e4b18088d409eb677216b5879f11bde2
