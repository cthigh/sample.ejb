#Tue May 23 20:10:20 BST 2017
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink_1.0.17.jar=6e6f7dd0eacab48ab239d9a728c48626
dev/api/ibm/com.ibm.websphere.appserver.api.persistence_1.0.17.jar=653937f1e053e303b1ce76f862e89638
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.persistence_1.0-javadoc.zip=ea050f0e4844c95127c51c5e378cfb58
lib/com.ibm.ws.persistence_1.0.17.jar=b626782bbbd77cae5f7c69dbea861535
lib/features/com.ibm.ws.persistence-1.0.mf=7b58982affcbfd1d22b1b5df711ae3d3
bin/tools/ws-generateddlutil.jar=3a674bbf25bef34974efb0bcb730222a
lib/com.ibm.ws.persistence.mbean_1.0.17.jar=a3898a95861aea8eb57de2fb645976f9
lib/com.ibm.ws.persistence.utility_1.0.17.jar=d1fe93ab3bb7707a9430be503a598709
