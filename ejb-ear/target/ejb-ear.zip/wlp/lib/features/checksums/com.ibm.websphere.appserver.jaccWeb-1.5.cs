#Tue May 23 20:10:19 BST 2017
dev/api/spec/com.ibm.websphere.javaee.jacc.1.5_1.0.17.jar=a611321d4e7e7ea421dbec11374f1fa7
lib/features/com.ibm.websphere.appserver.jaccWeb-1.5.mf=d74fbe5b9ebf12fa032ee7285ebc4f33
lib/com.ibm.ws.security.authorization.jacc.web_1.0.17.jar=d58e0322112ae49291beb0b367b78aba
