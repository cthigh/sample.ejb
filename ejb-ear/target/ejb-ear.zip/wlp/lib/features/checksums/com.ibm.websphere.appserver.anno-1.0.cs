#Tue May 23 20:10:19 BST 2017
lib/features/com.ibm.websphere.appserver.anno-1.0.mf=65633aeedf39157364611d0bad9763b0
lib/com.ibm.ws.anno_1.0.17.jar=53ba3f99629a2dc34c9f1fd81d59a5b5
dev/spi/ibm/com.ibm.websphere.appserver.spi.anno_1.0.17.jar=744a492528a377c74efb4280ff5e6ad0
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.anno_1.0-javadoc.zip=4772257a87e82915edaf5a8833a40cbf
